import random
import pygame
import math

SCREENWIDTH = 960
SCREENHEIGHT = 540
TITLE = 'Wave Shooter'
FPS = 60
ISRUNNING = True

RED = (255,0,0)
GREEN = (0,255,0)
DARK_GREEN = (1,50,32)
LIGHT_BLUE = (173,216,230)
SAND_YELLOW = (211,169,108)
GRAY = (128,128,128)
WHITE = (255,255,255)

pygame.init()
pygame.mixer.init()
game_screen = pygame.display.set_mode((SCREENWIDTH, SCREENHEIGHT))
game_clock = pygame.time.Clock()
pygame.display.set_caption(TITLE)
font = pygame.font.Font("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_font/Grand9K Pixel.ttf", 36)
font_big = pygame.font.Font("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_font/Grand9K Pixel.ttf", 50)
font_small = pygame.font.Font("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_font/Grand9K Pixel.ttf", 24)

#Other
game_over = False
game_paused = False
bonebreak_rounds = False
flash_step = False
lifesteal_rounds = False
adrenaline_rush = False
adrenaline_rush_active = False
long_term_investment = False
hunters_resilience = False
electric_field = False
electric_field_visual = pygame.Surface((130,160))
electric_field_visual.fill((LIGHT_BLUE))
electric_field_hitbox = electric_field_visual.get_rect()
on_fire = False
on_fire_active = False
MenuMusicPlaying = False
Soundtrack1Playing = False
ShootingSoundPlaying = False


#Sound effects
channel1 = pygame.mixer.Channel(0)
channel2 = pygame.mixer.Channel(1)

MenuMusic = pygame.mixer.Sound("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/menu_theme.mp3")
Soundtrack1 = pygame.mixer.Sound("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/soundtrack1.mp3")
ShootingSound = pygame.mixer.Sound("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/Shooting.mp3")

MenuMusic.set_volume(0.5)
Soundtrack1.set_volume(0.5)

# Background Visual
background_grass1 = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_background_updated.png")
background_grass1 = pygame.transform.scale(background_grass1, (SCREENWIDTH, SCREENHEIGHT))
background_pause_layer = pygame.Surface((SCREENWIDTH, SCREENHEIGHT), pygame.SRCALPHA)
background_pause_layer.fill((0,0,0,100))

#Menu
start_menu = True
start_menu_background = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/meny_bakgrund1.png")

# alla bilder under har jag själv gjort. Även de i Upgrades Visual.
menu_start_button_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_start.png")
menu_start_button = menu_start_button_img.get_rect()
menu_quit_button_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_quit.png")
menu_quit_button = menu_quit_button_img.get_rect()
menu_options_button_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_options.png")
menu_options_button = menu_options_button_img.get_rect()
menu_reset_button_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_reset.png")
menu_reset_button = menu_reset_button_img.get_rect()
menu_resume_button_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_resume.png")
menu_resume_button = menu_resume_button_img.get_rect()

#Upgrades Visual (Alla är mina egna bilder)
upgrade_swift_boots_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_swift_boots.png")
upgrade_swift_boots = upgrade_swift_boots_img.get_rect()
upgrade_quickfire_bullets_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_quickfire_bullets.png")
upgrade_quickfire_bullets = upgrade_quickfire_bullets_img.get_rect()
upgrade_hardened_armor_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_hardened_armor.png")
upgrade_hardened_armor = upgrade_hardened_armor_img.get_rect()
upgrade_sharpened_bullets_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_sharpened_bullets.png")
upgrade_sharpened_bullets = upgrade_sharpened_bullets_img.get_rect()
upgrade_thicker_skin_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_thicker_skin.png")
upgrade_thicker_skin = upgrade_thicker_skin_img.get_rect()
upgrade_lethal_precision_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_lethal_precision.png")
upgrade_lethal_precision = upgrade_lethal_precision_img.get_rect()
upgrade_bonebreak_rounds_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_bonebreak_rounds.png")
upgrade_bonebreak_rounds = upgrade_bonebreak_rounds_img.get_rect()
upgrade_flash_step_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_flash_step.png")
upgrade_flash_step = upgrade_flash_step_img.get_rect()
flash_step_off_cooldown = pygame.transform.scale(upgrade_flash_step_img, (64, 64))
flash_step_cooldown_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_flash_step_cooldown.png")
flash_step_cooldown_img = pygame.transform.scale(flash_step_cooldown_img, (64, 64))
upgrade_lifesteal_rounds_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_lifesteal_rounds.png")
upgrade_lifesteal_rounds = upgrade_lifesteal_rounds_img.get_rect()
upgrade_adrenaline_rush_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_adrenaline_rush.png")
upgrade_adrenaline_rush = upgrade_adrenaline_rush_img.get_rect()
upgrade_long_term_investment_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_long_term_investment.png")
upgrade_long_term_investment = upgrade_long_term_investment_img.get_rect()
upgrade_hunters_resilience_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_hunters_resilience.png")
upgrade_hunters_resilience = upgrade_hunters_resilience_img.get_rect()
upgrade_electric_field_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_electric_field.png")
upgrade_electric_field = upgrade_electric_field_img.get_rect()
upgrade_on_fire_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_on_fire.png")
upgrade_on_fire = upgrade_on_fire_img.get_rect()
on_fire_off_cooldown = pygame.transform.scale(upgrade_on_fire_img, (64, 64))
on_fire_cooldown_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_on_fire_cooldown.png")
on_fire_cooldown_img = pygame.transform.scale(on_fire_cooldown_img, (64, 64))

#Player/Monster Visual (Inte mina bilder)
player_idle_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_player_idle.png")
player_idle = pygame.transform.scale(player_idle_img, (30, 60))
player_idle_reverse = pygame.transform.flip(player_idle, True, False)
player_run1_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_player_run1.png")
player_run1 = pygame.transform.scale(player_run1_img, (30, 60))
player_run1_reverse = pygame.transform.flip(player_run1, True, False)
player_run2_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_player_run2.png")
player_run2 = pygame.transform.scale(player_run2_img, (30, 60))
player_run2_reverse = pygame.transform.flip(player_run2, True, False)
player_shooting_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_player_shooting.png")
player_shooting = pygame.transform.scale(player_shooting_img, (30, 60))
player_shooting_reverse = pygame.transform.flip(player_shooting, True, False)

NormalMonster_walk1_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_NormalMonster_walk1.png")
NormalMonster_walk1 = pygame.transform.scale(NormalMonster_walk1_img, (30, 60))
NormalMonster_walk1_reverse = pygame.transform.flip(NormalMonster_walk1, True, False)
NormalMonster_walk2_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_NormalMonster_walk2.png")
NormalMonster_walk2 = pygame.transform.scale(NormalMonster_walk2_img, (30, 60))
NormalMonster_walk2_reverse = pygame.transform.flip(NormalMonster_walk2, True, False)

FastMonster_run1_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_FastMonster_run1.png")
FastMonster_run1 = pygame.transform.scale(FastMonster_run1_img, (30, 60))
FastMonster_run1_reverse = pygame.transform.flip(FastMonster_run1, True, False)
FastMonster_run2_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_FastMonster_run2.png")
FastMonster_run2 = pygame.transform.scale(FastMonster_run2_img, (30, 60))
FastMonster_run2_reverse = pygame.transform.flip(FastMonster_run2, True, False)

TankMonster_walk1_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_TankMonster_walk1.png")
TankMonster_walk1 = pygame.transform.scale(TankMonster_walk1_img, (35, 65))
TankMonster_walk1_reverse = pygame.transform.flip(TankMonster_walk1, True, False)
TankMonster_walk2_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_TankMonster_walk2.png")
TankMonster_walk2 = pygame.transform.scale(TankMonster_walk2_img, (35, 65))
TankMonster_walk2_reverse = pygame.transform.flip(TankMonster_walk2, True, False)

#Bullet Visual (Inte mina bilder)

bullet_model = pygame.Surface((10,10))
bullet_model_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_bullet.png")
bullet_model1 = pygame.transform.scale(bullet_model_img, (10, 10))

#Upgrade Choices
level2_choice = False
level3_choice = False
level4_choice = False
level5_choice = False
level6_choice = False
level7_choice = False
level8_choice = False

#Game Over Visual
gameover_screen_img = pygame.image.load("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/pixel_gameover.png")

#Wave Control
wave_number = 0

#Bullet Stats
shot_timer = 100
shot_timer_other = 100
bullet_speed = 10
bullet_damage = 20
base_bullet_damage = 20

#Bullet Class (chatgpt)
class Bullet:
    def __init__(self, x, y, target_x, target_y, damage, speed=10):
        self.rect = bullet_model.get_rect(center=(x, y))
        angle = math.atan2(target_y - y, target_x - x) 
        self.dx = math.cos(angle) * speed 
        self.dy = math.sin(angle) * speed 
        self.damage = damage

    def move(self):
        self.rect.x += self.dx
        self.rect.y += self.dy

    def off_screen(self):
        return (self.rect.x < 0 or self.rect.x > SCREENWIDTH or
                self.rect.y < 0 or self.rect.y > SCREENHEIGHT)
    
    def update_speed(self, new_speed, target_x, target_y):
        angle = math.atan2(target_y - self.rect.centery, target_x - self.rect.centerx)
        self.dx = math.cos(angle) * new_speed
        self.dy = math.sin(angle) * new_speed

#Bullets Visual
active_bullets = []

def create_bullet(_x,_y,target_x,target_y,damage):
    active_bullets.append(Bullet(_x,_y,target_x,target_y,damage))

#Player Visual
player_model = pygame.Surface((30,60))
player_model.fill((WHITE))
player_rect = player_model.get_rect()

def player_idle1():
    game_screen.blit(player_idle, (player_rect.x, player_rect.y))
def player_running1():
    game_screen.blit(player_run1, (player_rect.x, player_rect.y))
def player_running2():
    game_screen.blit(player_run2, (player_rect.x, player_rect.y))
def player_shooting1():
    game_screen.blit(player_shooting, (player_rect.x, player_rect.y))
#Player Spawn
player_rect.x = 480
player_rect.y = 270

#Player Stats
player_speed = 2
player_speed_other = 2
player_hp = 100
player_max_hp = 100
player_xp = 0
player_level = 1
player_xp_max = 1000+500*(player_level-1)**2
crit_rate = 0
crit_multiplier = 2
damage_reduction = 0

fps_timer = 60
button_timer = 0

#Player input
player_input = pygame.key.get_pressed()

#Mouse position
mouseX, mouseY = pygame.mouse.get_pos()

#Monster Class (delvis chatgpt)
class NormalMonster:
    def __init__(self, x, y, speed=1, hp=100):
        self.rect = pygame.Rect(x, y, 30, 60)
        self.hp = hp
        self.speed = speed
        self.slow_timer = -1

    def move_toward_player(self, player_x, player_y):

        if fps_timer % 4 == 0 and self.slow_timer > 0:
            pass
        elif game_paused:
            pass
        else:
            dx = player_x - self.rect.x
            dy = player_y - self.rect.y
            distance = math.sqrt(dx**2 + dy**2)

            if distance > 0:
                dx /= distance
                dy /= distance
                self.rect.x += dx * self.speed
                self.rect.y += dy * self.speed

        if not game_paused:
            if self.slow_timer > 0:
                self.slow_timer -= 1
            if self.slow_timer <= 0:
                self.slow_timer = -1

    def take_damage(self, damage, crit=False):
        if long_term_investment:
            damage += wave_number
        elif hunters_resilience:
            damage += 50*(1-player_hp/player_max_hp)
        if crit:
            damage *= crit_multiplier
        self.hp -= damage
        if bonebreak_rounds:
            self.slow_timer = 180

        return self.hp <= 0
    
    def take_electric_damage(self, damage):
        self.hp -= damage

        return self.hp <= 0
      

class FastMonster:
    def __init__(self, x, y, speed=2, hp=80):
        self.rect = pygame.Rect(x, y, 30, 60)
        self.hp = hp
        self.speed = speed
        self.slow_timer = -1

    def move_toward_player(self, player_x, player_y):

        if fps_timer % 4 == 0 and self.slow_timer > 0:
            pass
        elif game_paused:
            pass
        else:
            dx = player_x - self.rect.x
            dy = player_y - self.rect.y
            distance = math.sqrt(dx**2 + dy**2)

            if distance > 0:
                dx /= distance
                dy /= distance
                self.rect.x += dx * self.speed
                self.rect.y += dy * self.speed

        if not game_paused:
            if self.slow_timer > 0:
                self.slow_timer -= 1
            if self.slow_timer <= 0:
                self.slow_timer = -1

    def take_damage(self, damage, crit=False):
        if long_term_investment:
            damage += wave_number
        elif hunters_resilience:
            damage += 50*(1-player_hp/player_max_hp)
        if crit:
            damage *= crit_multiplier
        self.hp -= damage
        if bonebreak_rounds:
            self.slow_timer = 180

        return self.hp <= 0
    
    def take_electric_damage(self, damage):
        self.hp -= damage
        
        return self.hp <= 0
      

class TankMonster:
    def __init__(self, x, y, speed=1, hp=400):
        self.rect = pygame.Rect(x, y, 35, 65)
        self.hp = hp
        self.speed = speed
        self.slow_timer = -1

    def move_toward_player(self, player_x, player_y):

        if fps_timer % 4 == 0 and self.slow_timer > 0:
            pass
        elif game_paused:
            pass
        else:
            dx = player_x - self.rect.x
            dy = player_y - self.rect.y
            distance = math.sqrt(dx**2 + dy**2)

            if distance > 0:
                dx /= distance
                dy /= distance
                self.rect.x += dx * self.speed
                self.rect.y += dy * self.speed

        if not game_paused:
            if self.slow_timer > 0:
                self.slow_timer -= 1
            if self.slow_timer <= 0:
                self.slow_timer = -1

    def take_damage(self, damage, crit=False):
        if long_term_investment:
            damage += wave_number
        elif hunters_resilience:
            damage += 50*(1-player_hp/player_max_hp)
        if crit:
            damage *= crit_multiplier
        self.hp -= damage
        if bonebreak_rounds:
            self.slow_timer = 180

        return self.hp <= 0

    def take_electric_damage(self, damage):
        self.hp -= damage

        return self.hp <= 0
      

#Monster Spawn
NormalMonsters = []
FastMonsters = []
TankMonsters = []

WaveSpawnTokens = 0
WaveSpawnTokensMax = 0

def spawn_monster():
    global WaveSpawnTokens
    global WaveSpawnTokensMax
    direction = random.randint(1, 4)
    
    if direction == 1: #North
        x, y = random.randint(0, SCREENWIDTH), random.randint(-300, -200)
    elif direction == 2: #West
        x, y = random.randint(-200, -100), random.randint(0, SCREENHEIGHT)
    elif direction == 3: #East
        x, y = random.randint(SCREENWIDTH, SCREENWIDTH + 100), random.randint(0, SCREENHEIGHT)
    else: #South
        x, y = random.randint(0, SCREENWIDTH), random.randint(SCREENHEIGHT, SCREENHEIGHT + 100)

        if wave_number < 5:
            if WaveSpawnTokens + 1 <= WaveSpawnTokensMax:
                NormalMonsters.append(NormalMonster(x, y))
                WaveSpawnTokens += 1
        elif wave_number >= 5 and wave_number < 10:
            which_monster = random.randint(1, 2)
            if which_monster == 1 and WaveSpawnTokens + 1 <= WaveSpawnTokensMax:
                NormalMonsters.append(NormalMonster(x, y))
                WaveSpawnTokens += 1
            elif which_monster == 2 and WaveSpawnTokens + 2 <= WaveSpawnTokensMax:
                FastMonsters.append(FastMonster(x, y))
                WaveSpawnTokens += 2
        elif wave_number >= 10:
            which_monster = random.randint(1, 3)
            if which_monster == 1 and WaveSpawnTokens + 1 <= WaveSpawnTokensMax:
                NormalMonsters.append(NormalMonster(x, y))
                WaveSpawnTokens += 1
            elif which_monster == 2 and WaveSpawnTokens + 2 <= WaveSpawnTokensMax:
                FastMonsters.append(FastMonster(x, y))
                WaveSpawnTokens += 2
            elif which_monster == 3 and WaveSpawnTokens + 4 <= WaveSpawnTokensMax:
                TankMonsters.append(TankMonster(x, y))
                WaveSpawnTokens += 4

#Effects/Events
iframes_end = pygame.USEREVENT + 1
flash_step_cooldown_end = pygame.USEREVENT + 2
adrenaline_rush_end = pygame.USEREVENT + 3
electric_field_cooldown_end = pygame.USEREVENT + 4
on_fire_cooldown_end = pygame.USEREVENT + 5
on_fire_active_end = pygame.USEREVENT + 6

player_iframes = False
flash_step_cooldown = False
electric_field_cooldown = False
on_fire_cooldown = False

def iframes_start():
    global player_iframes
    player_iframes = True
    pygame.time.set_timer(iframes_end, 500)

def flash_step_cooldown_start():
    global flash_step_cooldown
    flash_step_cooldown = True
    pygame.time.set_timer(flash_step_cooldown_end, 5000)

def adrenaline_rush_start():
    global player_speed_other
    global adrenaline_rush_active
    player_speed_other *= 1.5
    adrenaline_rush_active = True
    pygame.time.set_timer(adrenaline_rush_end, 3000)

def electric_field_cooldown_start():
    global electric_field_cooldown
    electric_field_cooldown = True
    pygame.time.set_timer(electric_field_cooldown_end, 1000)

def on_fire_start():
    global on_fire_active
    global bullet_damage
    global base_bullet_damage
    if not on_fire_active:
        on_fire_active = True
        bullet_damage = base_bullet_damage * 2
        on_fire_cooldown_start()
        pygame.time.set_timer(on_fire_active_end, 5000)

def on_fire_cooldown_start():
    global on_fire_cooldown
    on_fire_cooldown = True
    pygame.time.set_timer(on_fire_cooldown_end, 15000)

def game_reset():
    global player_hp
    global player_level
    global player_xp
    global player_speed_other
    global wave_number
    global player_rect
    global bonebreak_rounds
    global flash_step
    global lifesteal_rounds
    global adrenaline_rush
    global long_term_investment
    global hunters_resilience
    global electric_field
    global on_fire
    global NormalMonsters
    global FastMonsters
    global TankMonsters
    player_hp = 100
    player_level = 1
    player_xp = 0
    player_speed_other = 2
    wave_number = 0
    player_rect.x = 480
    player_rect.y = 270
    bonebreak_rounds = False
    flash_step = False
    lifesteal_rounds = False
    adrenaline_rush = False
    long_term_investment = False
    hunters_resilience = False
    electric_field = False
    on_fire = False
    NormalMonsters = []
    FastMonsters = []
    TankMonsters = []




#Main Game Loop

while ISRUNNING:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            ISRUNNING = False
        elif event.type == iframes_end:
            player_iframes = False
            pygame.time.set_timer(iframes_end, 0)
        elif event.type == flash_step_cooldown_end:
            flash_step_cooldown = False
            pygame.time.set_timer(flash_step_cooldown_end, 0)
        elif event.type == adrenaline_rush_end:
            player_speed_other *= 2/3
            adrenaline_rush_active = False
            pygame.time.set_timer(adrenaline_rush_end, 0)
        elif event.type == electric_field_cooldown_end:
            electric_field_cooldown = False
            pygame.time.set_timer(electric_field_cooldown_end, 0)
        elif event.type == on_fire_active_end:
            on_fire_active = False
            bullet_damage = base_bullet_damage
            pygame.time.set_timer(on_fire_active_end, 0)
        elif event.type == on_fire_cooldown_end:
            on_fire_cooldown = False
            pygame.time.set_timer(on_fire_cooldown_end, 0)

    #Update Mouse Position
    mouseX, mouseY = pygame.mouse.get_pos()

    #FPS Timer
    if not game_paused:
        fps_timer -= 1
        if fps_timer <= 0:
            fps_timer = 60

    #Highscore

    try:
        file = open("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/highscore_save.txt", "r")
        highscore = int(file.read())
        file.close()
    except:
        highscore = 0

    current_score = 0

    current_score = wave_number

    if current_score > highscore:
        file = open("Programmering 1/LTG 2024-2025/Slutprojekt_Spel/highscore_save.txt", "w")
        file.write(str(current_score))
        file.close()
        
    #Menu
    highscore_text = font_small.render(f"Highscore: {highscore}", True, WHITE)

    if start_menu:
        button_timer += 1
        game_screen.blit(start_menu_background, (0, 0))
        game_screen.blit(menu_start_button_img, (300, 100))
        game_screen.blit(menu_quit_button_img, (300, 350))
        game_screen.blit(menu_options_button_img, (300, 225))
        game_screen.blit(highscore_text, (20, 20))

        menu_start_button.topleft = (300, 100)
        menu_quit_button.topleft = (300, 350)
        menu_options_button.topleft = (300, 225)
        
        if not MenuMusicPlaying:
            Soundtrack1.stop()
            MenuMusic.play(loops=-1)
            MenuMusicPlaying = True
            Soundtrack1Playing = False

        if menu_start_button.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            start_menu = False

            if not Soundtrack1Playing:
                MenuMusic.stop()
                channel1.play(Soundtrack1, loops=-1)
                Soundtrack1Playing = True
                MenuMusicPlaying = False
        if menu_quit_button.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            if button_timer > 60:
                ISRUNNING = False

        pygame.display.update()
        game_clock.tick(FPS)
        continue

    #Keybinds
    player_input = pygame.key.get_pressed()

    if player_input[pygame.K_ESCAPE]:
        game_paused = True

    if player_input[pygame.K_w]:
        player_rect.y -= player_speed
    if player_input[pygame.K_a]:
        player_rect.x -= player_speed
    if player_input[pygame.K_s]:
        player_rect.y += player_speed
    if player_input[pygame.K_d]:
        player_rect.x += player_speed

    if player_input[pygame.K_SPACE] and player_input[pygame.K_w] and not flash_step_cooldown:
        player_rect.y -= 50
        flash_step_cooldown_start()
    if player_input[pygame.K_SPACE] and player_input[pygame.K_a] and not flash_step_cooldown:
        player_rect.x -= 50
        flash_step_cooldown_start()
    if player_input[pygame.K_SPACE] and player_input[pygame.K_s] and not flash_step_cooldown:
        player_rect.y += 50
        flash_step_cooldown_start()
    if player_input[pygame.K_SPACE] and player_input[pygame.K_d] and not flash_step_cooldown:
        player_rect.x += 50
        flash_step_cooldown_start()

    if player_input[pygame.K_r] and on_fire and not on_fire_cooldown:
        on_fire_start()

    if electric_field:
        electric_field_hitbox.topleft = (player_rect.x-50, player_rect.y-50)
        if not game_paused:
            for monster in NormalMonsters[:]:
                if electric_field_hitbox.colliderect(monster.rect) and not electric_field_cooldown:
                    monster.take_electric_damage(20)
                    if monster.hp <= 0:
                        NormalMonsters.remove(monster)
                    electric_field_cooldown()
            for monster in FastMonsters[:]:
                if electric_field_hitbox.colliderect(monster.rect) and not electric_field_cooldown:
                    monster.take_electric_damage(20)
                    electric_field_cooldown()
                    if monster.hp <= 0:
                        FastMonsters.remove(monster)
            for monster in TankMonsters[:]:
                if electric_field_hitbox.colliderect(monster.rect) and not electric_field_cooldown:
                    monster.take_electric_damage(20)
                    if monster.hp <= 0:
                        TankMonsters.remove(monster)
                    electric_field_cooldown()

    #Aiming/shooting
    if not game_paused:
        shot_timer -= 1
        if shot_timer <= 0:
            create_bullet(player_rect.centerx, player_rect.centery, mouseX, mouseY, bullet_damage)
            if not game_over:
                channel2.play(ShootingSound)
            shot_timer = shot_timer_other
    
    #Update bullets (chatgpt)
    for bullet in active_bullets[:]:
        bullet.move()
        
        for monster in NormalMonsters[:]:
            if bullet.rect.colliderect(monster.rect):
                is_crit = random.randint(1, 100) <= crit_rate
                if lifesteal_rounds and player_hp < player_max_hp:
                    player_hp += 1
                if monster.take_damage(bullet.damage, crit=is_crit):
                    NormalMonsters.remove(monster)
                    player_xp += 200
                try:
                    active_bullets.remove(bullet)
                except: pass
                break

        for monster in FastMonsters[:]:
            if bullet.rect.colliderect(monster.rect):
                is_crit = random.randint(1, 100) <= crit_rate
                if lifesteal_rounds and player_hp < player_max_hp:
                    player_hp += 1
                if monster.take_damage(bullet.damage, crit=is_crit):
                    FastMonsters.remove(monster)
                    player_xp += 400
                try:
                    active_bullets.remove(bullet)
                except: pass
                break

        for monster in TankMonsters[:]:
            if bullet.rect.colliderect(monster.rect):
                is_crit = random.randint(1, 100) <= crit_rate
                if lifesteal_rounds and player_hp < player_max_hp:
                    player_hp += 1
                if monster.take_damage(bullet.damage, crit=is_crit):
                    TankMonsters.remove(monster)
                    player_xp += 800
                try:
                    active_bullets.remove(bullet)
                except: pass
                break
    try:
        if bullet.off_screen():  
            active_bullets.remove(bullet)
    except: pass

    #Game paused
    if game_paused:
        player_speed = 0
    else:
        bullet_speed = 10
        player_speed = player_speed_other

    #Leveling up
    player_xp_max = 1000+500*(player_level-1)**2

    if player_xp >= 1000+500*(player_level-1)**2:
        player_xp = 0
        player_level+=1
        game_paused = True
    
        if player_level == 2:
            level2_choice = True
        elif player_level == 3:
            level3_choice = True
        elif player_level == 4:
            level4_choice = True
        elif player_level == 5:
            level5_choice = True
        elif player_level == 6:
            level6_choice = True
        elif player_level == 7:
            level7_choice = True
        elif player_level == 8:
            level8_choice = True

    if level2_choice:
        if upgrade_swift_boots.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            player_speed_other = 2.5
            game_paused = False
            level2_choice = False
        elif upgrade_quickfire_bullets.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            shot_timer_other = 75
            game_paused = False
            level2_choice = False

    if level3_choice:  
        if upgrade_sharpened_bullets.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            bullet_damage += bullet_damage
            game_paused = False
            level3_choice = False
        elif upgrade_hardened_armor.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            damage_reduction += 25
            game_paused = False
            level3_choice = False
    
    if level4_choice:
        if upgrade_thicker_skin.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            player_max_hp = 130
            player_hp += 30
            game_paused = False
            level4_choice = False
        elif upgrade_lethal_precision.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            crit_rate += 20
            game_paused = False
            level4_choice = False
    
    if level5_choice:
        if upgrade_bonebreak_rounds.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            bonebreak_rounds = True
            game_paused = False
            level5_choice = False
        elif upgrade_flash_step.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            flash_step = True
            game_paused = False
            level5_choice = False

    if level6_choice:
        if upgrade_lifesteal_rounds.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            lifesteal_rounds = True
            game_paused = False
            level6_choice = False
        elif upgrade_adrenaline_rush.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            adrenaline_rush = True
            game_paused = False
            level6_choice = False

    if level7_choice:
        if upgrade_long_term_investment.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            long_term_investment = True
            game_paused = False
            level7_choice = False
        elif upgrade_hunters_resilience.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            hunters_resilience = True
            game_paused = False
            level7_choice = False

    if level8_choice:
        if upgrade_electric_field.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            electric_field = True
            game_paused = False
            level8_choice = False
        elif upgrade_on_fire.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            on_fire = True
            game_paused = False
            level8_choice = False
        
    #Game-over
    continue_text = font_big.render("Press SPACE to continue", True, (LIGHT_BLUE))
    current_score_text = font_small.render(f"Your score: {current_score}", True, (LIGHT_BLUE))
    if player_hp <= 0:
        game_over = True
    if game_over:
        game_screen.blit(gameover_screen_img, (0, 0))
        game_screen.blit(continue_text, (150, 400))
        game_screen.blit(current_score_text, (SCREENWIDTH/2-70, 20))

        Soundtrack1.stop()

        if player_input[pygame.K_SPACE]:
            game_reset()
            MenuMusicPlaying = False
            start_menu = True
            game_over = False
            continue

        pygame.display.update()
        game_clock.tick(FPS)
        continue

    #Monster spawning each wave + player rewards

    if NormalMonsters == [] and FastMonsters == [] and TankMonsters == []:
        if wave_number > 0:
            player_xp += 1000
            player_hp = min(player_hp + 20, player_max_hp)
        wave_number += 1
        wave_spawn = True

    if wave_spawn == True:    
        WaveSpawnTokensMax = wave_number
        while WaveSpawnTokens < WaveSpawnTokensMax:
            spawn_monster()
        else:
            wave_spawn = False
            WaveSpawnTokens = 0
    
    #Player movement Visuals
    if shot_timer >= 0:
            player_shooting1()
    elif player_input[pygame.K_w] or player_input[pygame.K_a] or player_input[pygame.K_s] or player_input[pygame.K_d]:
        if fps_timer <= 30:
            player_running1()
        elif fps_timer >= 31:
            player_running2()
    else:
        player_idle1()

    #Shooting Audio
    if shot_timer <= 0:
        ShootingSound.play()

    #Monster movement
    for monster in NormalMonsters:
        monster.move_toward_player(player_rect.x, player_rect.y)
        
        if player_rect.colliderect(monster.rect) and not player_iframes:
            damage_taken=10*(1-damage_reduction/100)
            player_hp -= damage_taken
            if adrenaline_rush and not adrenaline_rush_active:
                adrenaline_rush_start()
            iframes_start()

    for monster in FastMonsters:
        monster.move_toward_player(player_rect.x, player_rect.y)
        
        if player_rect.colliderect(monster.rect) and not player_iframes:
            damage_taken=10*(1-damage_reduction/100)
            player_hp -= damage_taken
            if adrenaline_rush and not adrenaline_rush_active:
                adrenaline_rush_start()
            iframes_start()

    for monster in TankMonsters:
        monster.move_toward_player(player_rect.x, player_rect.y)
        
        if player_rect.colliderect(monster.rect) and not player_iframes:
            damage_taken=10*(1-damage_reduction/100)
            player_hp -= damage_taken
            if adrenaline_rush and not adrenaline_rush_active:
                adrenaline_rush_start()
            iframes_start()


    #Texts
    hp_text = font.render(str(int(player_hp))+"/"+str(player_max_hp), True, (255,255,255))
    wave_text = font.render("Wave " + str(wave_number), True, (255,255,255))
    xp_text = font.render("XP: " + str(player_xp) + "/" + str(player_xp_max), True, (255,255,255))
    level_text = font.render("Lvl. " + str(player_level), True, (255,255,255))
    swift_boots_text = font.render("Swift Boots", True, (255,255,255))
    swift_boots_desc = font_small.render("25% Movement speed", True, (255,255,255))
    quickfire_bullets_text = font.render("Quickfire Bullets", True, (255,255,255))
    quickfire_bullets_desc = font_small.render("25% Quicker shooting", True, (255,255,255))
    sharpened_bullets_text = font.render("Sharpened Bullets", True, (255,255,255))
    sharpened_bullets_desc = font_small.render("Deal double damage", True, (255,255,255))
    hardened_armor_text = font.render("Hardened Armor", True, (255,255,255))
    hardened_armor_desc = font_small.render("25% Damage reduction", True, (255,255,255))
    thicker_skin_text = font.render("Thicker Skin", True, (255,255,255))
    thicker_skin_desc = font_small.render("30% More health", True, (255,255,255))
    lethal_precision_text = font.render("Lethal Precision", True, (255,255,255))
    lethal_precision_desc = font_small.render("20% Increased crit rate", True, (255,255,255))
    bonebreak_rounds_text = font.render("Bonebreak Rounds", True, (255,255,255))
    bonebreak_rounds_desc = font_small.render("25% Slow on-hit", True, (255,255,255))
    flash_step_text = font.render("Flash Step", True, (255,255,255))
    flash_step_desc = font_small.render("Dash a short distance", True, (255,255,255))
    lifesteal_rounds_text = font.render("Lifesteal Rounds", True, (255,255,255))
    lifesteal_rounds_desc = font_small.render("Heal 1 hp on-hit", True, (255,255,255))
    adrenaline_rush_text = font.render("Adrenaline Rush", True, (255,255,255))
    adrenaline_rush_desc = font_small.render("50% Movement speed when taking damage", True, (255,255,255))
    long_term_investment_text = font.render("Long Term Investment", True, (255,255,255))
    long_term_investment_desc = font_small.render("Increase damage = Wave number", True, (255,255,255))
    hunters_resilience_text = font.render("Hunters Resilience", True, (255,255,255))
    hunters_resilience_desc = font_small.render("Lower health = More damage", True, (255,255,255))
    electric_field_text = font.render("Electric Field", True, (255,255,255))
    electric_field_desc = font_small.render("Auto damage enemies close by", True, (255,255,255))
    on_fire_text = font.render("Rampage", True, (255,255,255))
    on_fire_desc = font_small.render("Deal double damage", True, (255,255,255))

    #Draw everything
    game_screen.blit(background_grass1, (0, 0))
    for bullet in active_bullets:
        game_screen.blit(bullet_model1, bullet.rect.topleft)

    if electric_field:
        game_screen.blit(electric_field_visual, electric_field_hitbox.topleft)

    #Player movement Visuals
    if mouseX > player_rect.centerx and shot_timer <= 10:
        game_screen.blit(player_shooting, (player_rect.x, player_rect.y))
    elif mouseX > player_rect.centerx and (player_input[pygame.K_w] or player_input[pygame.K_a] or player_input[pygame.K_s] or player_input[pygame.K_d]):
        if fps_timer <= 30:
            game_screen.blit(player_run1, (player_rect.x, player_rect.y))
        elif fps_timer > 31:
            game_screen.blit(player_run2, (player_rect.x, player_rect.y))
    elif mouseX > player_rect.centerx and not (player_input[pygame.K_w] or player_input[pygame.K_a] or player_input[pygame.K_s] or player_input[pygame.K_d]):
        game_screen.blit(player_idle, (player_rect.x, player_rect.y))

    if mouseX < player_rect.centerx and shot_timer <= 10:
        game_screen.blit(player_shooting_reverse, (player_rect.x, player_rect.y))
    elif mouseX < player_rect.centerx and (player_input[pygame.K_w] or player_input[pygame.K_a] or player_input[pygame.K_s] or player_input[pygame.K_d]):
        if fps_timer <= 30:
            game_screen.blit(player_run1_reverse, (player_rect.x, player_rect.y))
        elif fps_timer > 31:
            game_screen.blit(player_run2_reverse, (player_rect.x, player_rect.y))
    elif mouseX < player_rect.centerx and not (player_input[pygame.K_w] or player_input[pygame.K_a] or player_input[pygame.K_s] or player_input[pygame.K_d]):
        game_screen.blit(player_idle_reverse, (player_rect.x, player_rect.y))
        
    #Normal Zombie movement Visuals
    for monster in NormalMonsters:
        if monster.rect.centerx < player_rect.centerx:
            if fps_timer <= 30:
                game_screen.blit(NormalMonster_walk1, (monster.rect.x, monster.rect.y))
            elif fps_timer > 31:
                game_screen.blit(NormalMonster_walk2, (monster.rect.x, monster.rect.y))
        elif monster.rect.centerx > player_rect.centerx:
            if fps_timer <= 30:
                game_screen.blit(NormalMonster_walk1_reverse, (monster.rect.x, monster.rect.y))
            elif fps_timer > 31:
                game_screen.blit(NormalMonster_walk2_reverse, (monster.rect.x, monster.rect.y))

    #Fast Zombie movement Visuals
    for monster in FastMonsters:
        if monster.rect.centerx < player_rect.centerx:
            if fps_timer <= 30:
                game_screen.blit(FastMonster_run1, (monster.rect.x, monster.rect.y))
            elif fps_timer > 31:
                game_screen.blit(FastMonster_run2, (monster.rect.x, monster.rect.y))
        elif monster.rect.centerx > player_rect.centerx:
            if fps_timer <= 30:
                game_screen.blit(FastMonster_run1_reverse, (monster.rect.x, monster.rect.y))
            elif fps_timer > 31:
                game_screen.blit(FastMonster_run2_reverse, (monster.rect.x, monster.rect.y))
    
    #Tank Zombie movement Visuals
    for monster in TankMonsters:
        if monster.rect.centerx < player_rect.centerx:
            if fps_timer <= 30:
                game_screen.blit(TankMonster_walk1, (monster.rect.x, monster.rect.y))
            elif fps_timer > 31:
                game_screen.blit(TankMonster_walk2, (monster.rect.x, monster.rect.y))
        elif monster.rect.centerx > player_rect.centerx:
            if fps_timer <= 30:
                game_screen.blit(TankMonster_walk1_reverse, (monster.rect.x, monster.rect.y))
            elif fps_timer > 31:
                game_screen.blit(TankMonster_walk2_reverse, (monster.rect.x, monster.rect.y))

    game_screen.blit(hp_text, (10, 0))
    game_screen.blit(wave_text, (SCREENWIDTH/2-50,0))
    game_screen.blit(xp_text, (SCREENWIDTH-320, 0))
    game_screen.blit(level_text, (0, 40))

    if flash_step_cooldown and flash_step:
        game_screen.blit(flash_step_cooldown_img, (880, 460))
    if not flash_step_cooldown and flash_step:
        game_screen.blit(flash_step_off_cooldown, (880, 460))
    if on_fire_cooldown and on_fire:
        game_screen.blit(on_fire_cooldown_img, (806, 460))
    if not on_fire_cooldown and on_fire:
        game_screen.blit(on_fire_off_cooldown, (806, 460))

    if game_paused:
        game_screen.blit(background_pause_layer, (0, 0))
    if level2_choice: 
        upgrade_swift_boots.topleft = (200, 150)
        game_screen.blit(upgrade_swift_boots_img, (200, 150))
        game_screen.blit(swift_boots_text, (200, 70))
        game_screen.blit(swift_boots_desc, (200, 114))
        upgrade_quickfire_bullets.topleft = (SCREENWIDTH-366, 150)
        game_screen.blit(upgrade_quickfire_bullets_img, (SCREENWIDTH-366, 150))
        game_screen.blit(quickfire_bullets_text, (SCREENWIDTH-366, 70))
        game_screen.blit(quickfire_bullets_desc, (SCREENWIDTH-366, 114))
    if level3_choice:
        upgrade_sharpened_bullets.topleft = (200, 150)
        game_screen.blit(upgrade_sharpened_bullets_img, (200, 150))
        game_screen.blit(sharpened_bullets_text, (200, 70))
        game_screen.blit(sharpened_bullets_desc, (200, 114))
        upgrade_hardened_armor.topleft = (SCREENWIDTH-366, 150)
        game_screen.blit(upgrade_hardened_armor_img, (SCREENWIDTH-366, 150))
        game_screen.blit(hardened_armor_text, (SCREENWIDTH-366, 70))
        game_screen.blit(hardened_armor_desc, (SCREENWIDTH-366, 114))
    if level4_choice:
        upgrade_thicker_skin.topleft = (200, 150)
        game_screen.blit(upgrade_thicker_skin_img, (200, 150))
        game_screen.blit(thicker_skin_text, (200, 70))
        game_screen.blit(thicker_skin_desc, (200, 114))
        upgrade_lethal_precision.topleft = (SCREENWIDTH-366, 150)
        game_screen.blit(upgrade_lethal_precision_img, (SCREENWIDTH-366, 150))
        game_screen.blit(lethal_precision_text, (SCREENWIDTH-366, 70))
        game_screen.blit(lethal_precision_desc, (SCREENWIDTH-366, 114))
    if level5_choice:
        upgrade_bonebreak_rounds.topleft = (200, 150)
        game_screen.blit(upgrade_bonebreak_rounds_img, (200, 150))
        game_screen.blit(bonebreak_rounds_text, (200, 70))
        game_screen.blit(bonebreak_rounds_desc, (200, 114))
        upgrade_flash_step.topleft = (SCREENWIDTH-366, 150)
        game_screen.blit(upgrade_flash_step_img, (SCREENWIDTH-366, 150))
        game_screen.blit(flash_step_text, (SCREENWIDTH-366, 70))
        game_screen.blit(flash_step_desc, (SCREENWIDTH-366, 114))
    if level6_choice:
        upgrade_lifesteal_rounds.topleft = (200, 150)
        game_screen.blit(upgrade_lifesteal_rounds_img, (200, 150))
        game_screen.blit(lifesteal_rounds_text, (200, 70))
        game_screen.blit(lifesteal_rounds_desc, (200, 114))
        upgrade_adrenaline_rush.topleft = (SCREENWIDTH-366, 150)
        game_screen.blit(upgrade_adrenaline_rush_img, (SCREENWIDTH-366, 150))
        game_screen.blit(adrenaline_rush_text, (SCREENWIDTH-366, 70))
        game_screen.blit(adrenaline_rush_desc, (SCREENWIDTH-366, 114))
    if level7_choice:
        upgrade_long_term_investment.topleft = (200, 150)
        game_screen.blit(upgrade_long_term_investment_img, (200, 150))
        game_screen.blit(long_term_investment_text, (200, 70))
        game_screen.blit(long_term_investment_desc, (200, 114))
        upgrade_hunters_resilience.topleft = (SCREENWIDTH-366, 150)
        game_screen.blit(upgrade_hunters_resilience_img, (SCREENWIDTH-366, 150))
        game_screen.blit(hunters_resilience_text, (SCREENWIDTH-366, 70))
        game_screen.blit(hunters_resilience_desc, (SCREENWIDTH-366, 114))
    if level8_choice:
        upgrade_electric_field.topleft = (200, 150)
        game_screen.blit(upgrade_electric_field_img, (200, 150))
        game_screen.blit(electric_field_text, (200, 70))
        game_screen.blit(electric_field_desc, (200, 114))
        upgrade_on_fire.topleft = (SCREENWIDTH-366, 150)
        game_screen.blit(upgrade_on_fire_img, (SCREENWIDTH-366, 150))
        game_screen.blit(on_fire_text, (SCREENWIDTH-366, 70))
        game_screen.blit(on_fire_desc, (SCREENWIDTH-366, 114))

    if game_paused and not level2_choice and not level3_choice and not level4_choice and not level5_choice and not level6_choice and not level7_choice and not level8_choice:
        game_screen.blit(menu_quit_button_img, (300, 350))
        game_screen.blit(menu_resume_button_img, (300, 100))
        game_screen.blit(menu_reset_button_img, (300, 225))
        menu_quit_button.topleft = (300, 350)
        menu_resume_button.topleft = (300, 100)
        menu_reset_button.topleft = (300, 225)
        if menu_quit_button.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            start_menu = True
            game_paused = False
            game_reset()
            button_timer = 0
        if menu_resume_button.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            game_paused = False
        if menu_reset_button.collidepoint(mouseX, mouseY) and pygame.mouse.get_pressed()[0]:
            game_reset()
            game_paused = False

    pygame.display.update()
    game_clock.tick(FPS)

pygame.quit()